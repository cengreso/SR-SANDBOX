/**
 * @NApiVersion 2.1
 */
define(['N/https'],
	(https) => {

		const post = (options) => {
			log.debug('options',options)
			// https.get({
			// 	url: 'https://us-central1-itsm-932-infraops.cloudfunctions.net/urd-on2wp-bot-notification-ingestor-dev-main',
			// 	headers: {
			// 		'Content-Type': 'application/json',
			// 		'Authorization': "Bearer {custsecret_eve_apikey}"
			// 	},
			// 	credentials: ['custsecret_eve_apikey']
			// });
		}

		return {post}

	});

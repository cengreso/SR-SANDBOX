SELECT  subsidiary, id, firstname, lastname,
FROM employee
WHERE employee.id = ?